#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
export TERM=xterm;  #Copyright (C) 2007 Free Software Foundation, Inc. 
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>#Copyright (C) 2007 Free Software Foundation, Inc. 
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>#Copyright (C) 2007 Free Software Foundation, Inc. 
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>#Copyright (C) 2007 Free Software Foundation, Inc.      
#Everyone is permitted to copy and distribute verbatim copies#Copyright (C) 2007 Free Software Foundation, Inc. 
#of this license document, but changing it is not allowed.
git clone "${REPO_URL:-https://github.com/}" Renamer-Main 
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.       
cd Renamer-Main  #Copyright (C) 2007 Free Software Foundation, Inc. 
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
echo "🚀 BOT IS STARTING ❣️";  #Copyright (C) 2007 Free Software Fo
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
python3 bot.py   #Copyright (C) 2007 Free Software Foundation, Inc. 
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.
#Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
#Everyone is permitted to copy and distribute verbatim copies
#of this license document, but changing it is not allowed.









