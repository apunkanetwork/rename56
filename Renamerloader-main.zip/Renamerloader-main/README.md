# 𝑹𝑬𝑵𝑨𝑴𝑬 𝑩𝑶𝑻

Telegram File Renamer Bot 

<p align="center">
  <a href="https://www.python.org">
    <img src="http://ForTheBadge.com/images/badges/made-with-python.svg">

  </a>
</p>
</p>


### Deploye To Heroku ❣️
   heroku uyir 🔥

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/)


## Configs 

* `TG_BOT_TOKEN`  - Get bot token from @BotFather

* `API_ID` - From my.telegram.org 

* `API_HASH` - From my.telegram.org 

* `ADMIN` - AUTH or bot controllers id's multiple id use space to split 

* `DATABASE_URI`  - Mongo Database URL from https://cloud.mongodb.com/

* `DATABASE_NAME`  - Your database name from mongoDB. Default will be 'my'

* `FORCE_SUB` - your force sub channel username without @ 


## Botfather Commands
```
start - bot alive cheking
viewthumb - View Thumbnail
delthumb - Delete Thumbnail
set_caption - set a custom caption
see_caption - see your custom caption
del_caption - delete custom caption
users - admin only
broadcast - admin only
```

## ❣️Thanks
